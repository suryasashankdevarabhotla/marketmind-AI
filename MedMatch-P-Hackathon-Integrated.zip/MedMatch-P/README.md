# MedMatch-P — Privacy-Preserving Healthcare Data Matcher

A hackathon-ready Streamlit prototype for demonstrating privacy-first cross-dataset healthcare record matching.

## Features

- Live PII/sensitive-field scanner
- Automatic sanitization and generalization
- Privacy-preserving feature transformation
- ML-based candidate matching
- Match probability + explainability
- Human-review threshold
- Synthetic healthcare dataset generator
- Privacy audit trail
- Research-oriented aggregate workflow
- Architecture ready for future federated learning / differential privacy

## Run on Windows

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

The browser should open automatically. If it does not, open the localhost URL printed in the terminal.

## Demo flow

1. Open **Synthetic Data Lab**
2. Generate Dataset A + B
3. Open **Private Matcher**
4. Click **Use generated demo data**
5. Click **Sanitize & Run Private Matching**
6. Show the Privacy Shield
7. Show match probabilities and explanations
8. Open **Privacy Audit**

## Important

This is a hackathon prototype, not a production healthcare system. Use synthetic/de-identified data only. Hashing alone does not guarantee anonymity, and real deployment would require formal privacy/security assessment, governance, access controls, threat modeling, and applicable healthcare/data-protection compliance.

## Future production extensions

- Federated learning / secure multi-party computation
- Differential privacy for aggregate outputs
- Formal linkage-quality evaluation
- Stronger cryptographic protocols such as PSI where appropriate
- Role-based access control and key management
- Secure enclave / confidential-computing deployment
- Formal re-identification risk assessment


## Bundled benchmark workbook
The project includes `data/MedMatch-P-Datasets.xlsx` with Hospital_A, Hospital_B, Ground_Truth, and PII_Test_Demo sheets. Use **Load MedMatch-P Benchmark Excel** in Private Matcher to load it directly. The matching model is trained from the synthetic Ground_Truth labels.
