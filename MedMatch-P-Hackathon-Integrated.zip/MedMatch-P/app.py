import io, re, hashlib, time
from datetime import datetime
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, f1_score

st.set_page_config(page_title="MedMatch-P", page_icon="🛡️", layout="wide")

# -------------------- Styling --------------------
st.markdown("""
<style>
.main {background:#f7f9fc;}
.hero {padding:24px;border-radius:18px;background:linear-gradient(135deg,#0f172a,#164e63);color:white;margin-bottom:18px;}
.card {padding:16px;border:1px solid #dbe4ee;border-radius:14px;background:white;}
.metric {font-size:28px;font-weight:700;}
.small {color:#64748b;font-size:13px;}
</style>
""", unsafe_allow_html=True)

DIRECT_PII_PATTERNS = {
    "Email": r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
    "Phone": r"^\+?[\d\s().-]{8,}$",
    "Aadhaar/Gov ID": r"^\d{4}\s?\d{4}\s?\d{4}$",
}

PII_NAME_WORDS = ["name","full_name","patient_name","first_name","last_name","email","phone",
                  "mobile","address","aadhaar","aadhar","ssn","social_security","government_id",
                  "gov_id","passport","patient_id","national_id"]

KEEP_HINTS = ["age","gender","sex","zip","postal","region","diagnosis","condition","disease",
              "medication","drug","visit","date","month","lab","test","category"]

def log_event(event, status="OK"):
    st.session_state.setdefault("audit", []).append(
        {"Time": datetime.now().strftime("%H:%M:%S"), "Event": event, "Status": status}
    )

def hash_value(x, salt="medmatch-demo"):
    return hashlib.sha256((salt + "|" + str(x)).encode()).hexdigest()[:16]

def detect_pii(df):
    findings = []
    for c in df.columns:
        cl = str(c).lower().replace(" ","_")
        if any(w in cl for w in PII_NAME_WORDS):
            findings.append((c, "Column name indicates direct identifier", "HIGH"))
            continue
        sample = df[c].dropna().astype(str).head(100)
        for typ, pat in DIRECT_PII_PATTERNS.items():
            if len(sample) and sample.str.match(pat, na=False).mean() >= 0.75:
                findings.append((c, f"Values resemble {typ}", "HIGH"))
                break
    return findings

def privacy_transform(df):
    out = df.copy()
    removed, generalized, protected = [], [], []
    for c in list(out.columns):
        cl = str(c).lower().replace(" ","_")
        if any(w in cl for w in ["name","full_name","first_name","last_name","email","phone","mobile",
                                 "address","aadhaar","aadhar","ssn","passport","patient_id","national_id","gov_id"]):
            removed.append(c)
            out.drop(columns=[c], inplace=True)
            continue
        if "age" in cl:
            out[c] = pd.to_numeric(out[c], errors="coerce").round(-1)
            generalized.append(c)
        elif any(w in cl for w in ["zip","postal"]):
            out[c] = out[c].astype(str).str[:3] + "***"
            generalized.append(c)
        elif any(w in cl for w in ["date","visit"]):
            parsed = pd.to_datetime(out[c], errors="coerce")
            if parsed.notna().mean() > 0.5:
                out[c] = parsed.dt.to_period("M").astype(str)
                generalized.append(c)
        elif any(w in cl for w in ["diagnosis","condition","disease","medication","drug"]):
            out[c] = out[c].map(lambda x: hash_value(x) if pd.notna(x) else x)
            protected.append(c)
    return out, removed, generalized, protected

def normalize_columns(df):
    x = df.copy()
    x.columns = [re.sub(r"[^a-zA-Z0-9_]", "_", str(c).strip().lower()) for c in x.columns]
    return x

def choose_col(df, candidates):
    for c in df.columns:
        if any(k in c.lower() for k in candidates):
            return c
    return None

def pair_features(a, b):
    def val(row, c):
        return row[c] if c else None
    feats = {}
    age_a, age_b = val(a, AGE_A), val(b, AGE_B)
    try:
        aa, bb = float(age_a), float(age_b)
        feats["age_sim"] = max(0, 1 - abs(aa-bb)/50)
    except: feats["age_sim"] = 0.0
    for key, ca, cb in [("gender_sim", G_A,G_B),("diagnosis_sim",D_A,D_B),("medication_sim",M_A,M_B),("region_sim",R_A,R_B)]:
        if ca and cb:
            feats[key] = float(str(val(a,ca)).lower() == str(val(b,cb)).lower())
        else: feats[key] = 0.0
    va, vb = val(a,V_A), val(b,V_B)
    try:
        da, db = pd.to_datetime(va), pd.to_datetime(vb)
        feats["visit_sim"] = max(0, 1 - abs((da-db).days)/365)
    except:
        feats["visit_sim"] = float(str(va)[:7] == str(vb)[:7]) if va is not None and vb is not None else 0.0
    feats["feature_agreement"] = np.mean(list(feats.values()))
    return feats

def build_candidates(df_a, df_b, max_pairs=5000):
    n = min(len(df_a), 150)
    m = min(len(df_b), 150)
    rows = []
    for i in range(n):
        for j in range(m):
            f = pair_features(df_a.iloc[i], df_b.iloc[j])
            rows.append((i,j,f))
            if len(rows) >= max_pairs: return rows
    return rows

def train_demo_model():
    rng = np.random.default_rng(42)
    X, y = [], []
    for _ in range(2500):
        age = rng.random()
        gender = rng.integers(0,2)
        diag = rng.integers(0,2)
        med = rng.integers(0,2)
        region = rng.integers(0,2)
        visit = rng.random()
        score = .30*age+.15*gender+.25*diag+.15*med+.05*region+.10*visit
        label = int(score + rng.normal(0,.06) > .55)
        X.append([age,gender,diag,med,region,visit, np.mean([age,gender,diag,med,region,visit])])
        y.append(label)
    model = RandomForestClassifier(n_estimators=120, random_state=42, class_weight="balanced")
    model.fit(X,y)
    return model

MODEL, BENCHMARK = train_model_from_benchmark()

def score_pairs(df_a, df_b, top_n=50):
    pairs = build_candidates(df_a, df_b)
    if not pairs: return pd.DataFrame()
    rows=[]
    for i,j,f in pairs:
        X = np.array([[f[k] for k in ["age_sim","gender_sim","diagnosis_sim","medication_sim","region_sim","visit_sim","feature_agreement"]]])
        p = float(MODEL.predict_proba(X)[0,1])
        rows.append({"A_index":i,"B_index":j,"match_probability":p,**f})
    res = pd.DataFrame(rows).sort_values("match_probability", ascending=False).head(top_n)
    return res

def load_bundled_dataset():
    path = Path("data/MedMatch-P-Datasets.xlsx")
    if not path.exists(): return None, None, None
    A=normalize_columns(pd.read_excel(path,sheet_name="Hospital_A")); B=normalize_columns(pd.read_excel(path,sheet_name="Hospital_B")); GT=pd.read_excel(path,sheet_name="Ground_Truth")
    GT.columns=[str(c).strip().lower() for c in GT.columns]
    return A,B,GT

def train_model_from_benchmark():
    A,B,GT=load_bundled_dataset()
    if A is None: return train_fallback_model(), None
    global AGE_A,AGE_B,G_A,G_B,D_A,D_B,M_A,M_B,R_A,R_B,V_A,V_B
    AGE_A=choose_col(A,["age"]); AGE_B=choose_col(B,["age"]); G_A=choose_col(A,["gender","sex"]); G_B=choose_col(B,["gender","sex"]); D_A=choose_col(A,["diagnosis","condition","disease"]); D_B=choose_col(B,["diagnosis","condition","disease"]); M_A=choose_col(A,["medication","drug"]); M_B=choose_col(B,["medication","drug"]); R_A=choose_col(A,["region","zip","postal"]); R_B=choose_col(B,["region","zip","postal"]); V_A=choose_col(A,["visit","date"]); V_B=choose_col(B,["visit","date"])
    ai,bi=A.set_index("source_record_id"),B.set_index("source_record_id"); X=[]; y=[]
    for _,r in GT.iterrows():
        if r["hospital_A_record_id"] in ai.index and r["hospital_B_record_id"] in bi.index:
            f=pair_features(ai.loc[r["hospital_A_record_id"]],bi.loc[r["hospital_B_record_id"]]); X.append([f[k] for k in ["age_sim","gender_sim","diagnosis_sim","medication_sim","region_sim","visit_sim","feature_agreement"]]); y.append(int(r["is_true_match"]))
    model=RandomForestClassifier(n_estimators=250,max_depth=8,min_samples_leaf=2,random_state=42,class_weight="balanced_subsample"); model.fit(X,y)
    return model,{"pairs":len(y),"true_matches":sum(y),"A":A,"B":B,"GT":GT}

def train_fallback_model():
    rng=np.random.default_rng(42); X=[]; y=[]
    for _ in range(2500):
        vals=rng.random(6); score=.30*vals[0]+.15*vals[1]+.25*vals[2]+.15*vals[3]+.05*vals[4]+.10*vals[5]; X.append([*vals,vals.mean()]); y.append(int(score+rng.normal(0,.06)>.55))
    model=RandomForestClassifier(n_estimators=150,random_state=42,class_weight="balanced"); model.fit(X,y); return model

def synthetic_data(n=500, seed=7, shift=0):
    rng=np.random.default_rng(seed+shift)
    diseases=np.array(["Diabetes","Hypertension","Asthma","Cardiac","Arthritis","Migraine"])
    meds={"Diabetes":"Metformin","Hypertension":"Amlodipine","Asthma":"Salbutamol",
          "Cardiac":"Atorvastatin","Arthritis":"Ibuprofen","Migraine":"Sumatriptan"}
    rows=[]
    for i in range(n):
        age=int(rng.integers(18,80))
        gender=rng.choice(["F","M"])
        region=rng.choice(["North","South","East","West"])
        d=str(rng.choice(diseases))
        month=pd.Timestamp("2025-01-01")+pd.DateOffset(months=int(rng.integers(0,18)))
        rows.append({"record_id":f"{'A' if shift==0 else 'B'}{i+1:05d}","age":age,"gender":gender,
                     "region":region,"diagnosis":d,"medication":meds[d],
                     "visit_date":month.strftime("%Y-%m-%d")})
    return pd.DataFrame(rows)


# Column discovery is refreshed on every Streamlit rerun before any button action.
def set_feature_columns():
    global AGE_A, AGE_B, G_A, G_B, D_A, D_B, M_A, M_B, R_A, R_B, V_A, V_B
    if "safe_a" in st.session_state:
        A=st.session_state["safe_a"]; B=st.session_state["safe_b"]
        AGE_A=choose_col(A,["age"]); AGE_B=choose_col(B,["age"])
        G_A=choose_col(A,["gender","sex"]); G_B=choose_col(B,["gender","sex"])
        D_A=choose_col(A,["diagnosis","condition","disease"]); D_B=choose_col(B,["diagnosis","condition","disease"])
        M_A=choose_col(A,["medication","drug"]); M_B=choose_col(B,["medication","drug"])
        R_A=choose_col(A,["region","zip","postal"]); R_B=choose_col(B,["region","zip","postal"])
        V_A=choose_col(A,["visit","date"]); V_B=choose_col(B,["visit","date"])
    else:
        AGE_A=AGE_B=G_A=G_B=D_A=D_B=M_A=M_B=R_A=R_B=V_A=V_B=None

set_feature_columns()

# -------------------- Session --------------------
st.session_state.setdefault("audit", [])

st.markdown('<div class="hero"><h1>🛡️ MedMatch-P</h1><p>Privacy-Preserving Healthcare Data Matcher</p><p>Discover cross-dataset patient matches without exposing direct identifiers.</p></div>', unsafe_allow_html=True)

with st.sidebar:
    st.header("⚙️ Control Center")
    page = st.radio("Module", ["Dashboard","Private Matcher","Synthetic Data Lab","Privacy Audit"])
    st.divider()
    st.caption("Prototype note: use synthetic/de-identified data only. This demo is not a clinical decision system.")

if page=="Synthetic Data Lab":
    st.header("🧪 Synthetic Healthcare Data Lab")
    n=st.slider("Records per dataset",100,2000,500,100)
    if st.button("Generate Dataset A + B", type="primary"):
        st.session_state["df_a"]=synthetic_data(n,7,0)
        st.session_state["df_b"]=synthetic_data(n,7,1)
        log_event(f"Generated two synthetic datasets ({n} records each)")
        st.success("Synthetic datasets generated.")
    if "df_a" in st.session_state:
        c1,c2=st.columns(2)
        c1.dataframe(st.session_state["df_a"].head(10), use_container_width=True)
        c2.dataframe(st.session_state["df_b"].head(10), use_container_width=True)
    st.info("Synthetic data is intentionally used for the demo so no real patient information is needed.")

elif page=="Private Matcher":
    st.header("🔐 Private Matcher")
    c1,c2=st.columns(2)
    c_b1,c_b2=st.columns(2)
    with c_b1:
        if st.button("📊 Load MedMatch-P Benchmark Excel", type="primary"):
            ba,bb,gt=load_bundled_dataset(); st.session_state["df_a"],st.session_state["df_b"],st.session_state["ground_truth"]=ba,bb,gt; log_event("Loaded bundled MedMatch-P benchmark workbook"); st.rerun()
    with c_b2:
        if st.button("🧪 Generate New Demo Data"):
            st.session_state["df_a"]=synthetic_data(500,7,0); st.session_state["df_b"]=synthetic_data(500,7,1); log_event("Generated two synthetic datasets"); st.rerun()
    if BENCHMARK:
        st.subheader("🎯 Bundled Benchmark")
        q1,q2,q3=st.columns(3); q1.metric("Labeled pairs",f"{BENCHMARK['pairs']:,}"); q2.metric("Known true matches",f"{BENCHMARK['true_matches']:,}"); q3.metric("Training source","Ground Truth")
        st.caption("Metrics and model training use the supplied synthetic Ground_Truth sheet; they are not real-world clinical performance claims.")

    with c1:
        up_a=st.file_uploader("Dataset A (CSV)", type=["csv"], key="a")
    with c2:
        up_b=st.file_uploader("Dataset B (CSV)", type=["csv"], key="b")

    if st.button("Use generated demo data"):
        if "df_a" not in st.session_state:
            st.session_state["df_a"]=synthetic_data(500,7,0)
            st.session_state["df_b"]=synthetic_data(500,7,1)
        st.rerun()

    if up_a and up_b:
        st.session_state["df_a"]=pd.read_csv(up_a)
        st.session_state["df_b"]=pd.read_csv(up_b)
        log_event("Two CSV datasets uploaded")

    if "df_a" in st.session_state and "df_b" in st.session_state:
        raw_a,raw_b=st.session_state["df_a"],st.session_state["df_b"]
        t1,t2=st.columns(2)
        with t1:
            st.subheader("Dataset A")
            st.write(f"{len(raw_a):,} records × {len(raw_a.columns)} columns")
        with t2:
            st.subheader("Dataset B")
            st.write(f"{len(raw_b):,} records × {len(raw_b.columns)} columns")

        st.subheader("🕵️ Privacy Shield")
        findings_a=detect_pii(raw_a); findings_b=detect_pii(raw_b)
        total=len(findings_a)+len(findings_b)
        st.metric("Potential sensitive fields detected", total)
        if total:
            st.warning("Potential direct identifiers were detected. Processing will sanitize them before matching.")
            with st.expander("View detection results"):
                st.dataframe(pd.DataFrame(findings_a+findings_b, columns=["Field","Reason","Risk"]), use_container_width=True)
        else:
            st.success("No obvious direct-identifier columns detected.")

        if st.button("🛡️ Sanitize & Run Private Matching", type="primary"):
            pa,ra,ga,ha=privacy_transform(normalize_columns(raw_a))
            pb,rb,gb,hb=privacy_transform(normalize_columns(raw_b))
            st.session_state.update({"safe_a":pa,"safe_b":pb})
            set_feature_columns()
            log_event("PII scan and privacy transformation completed")
            st.session_state["match_results"]=score_pairs(pa,pb,50)
            log_event("ML matching completed")
            st.rerun()

        if "match_results" in st.session_state:
            res=st.session_state["match_results"]
            st.subheader("🤖 Explainable Match Results")
            high=int((res.match_probability>=.90).sum()) if len(res) else 0
            review=int(((res.match_probability>=.60)&(res.match_probability<.90)).sum()) if len(res) else 0
            no=int((res.match_probability<.60).sum()) if len(res) else 0
            a,b,c,d=st.columns(4)
            a.metric("Pairs analyzed",len(res)); b.metric("High confidence",high); c.metric("Human review",review); d.metric("Below threshold",no)
            st.dataframe(res.assign(match_probability=lambda x:(x.match_probability*100).round(1).astype(str)+"%"), use_container_width=True)
            st.caption("The prototype uses a Random Forest trained on synthetic pair features. It is intended for demonstration, not clinical identity resolution.")

            st.subheader("🔎 Selected Match Explanation")
            if len(res):
                idx=st.slider("Select result",0,len(res)-1,0)
                r=res.iloc[idx]
                st.write(f"**Probability: {r.match_probability*100:.1f}%**")
                cols=st.columns(6)
                labels=[("Age",r.age_sim),("Gender",r.gender_sim),("Diagnosis",r.diagnosis_sim),("Medication",r.medication_sim),("Region",r.region_sim),("Visit",r.visit_sim)]
                for col,(lab,val) in zip(cols,labels): col.metric(lab,f"{val*100:.0f}%")
                if r.match_probability>=.90: st.success("HIGH-CONFIDENCE MATCH — eligible for review/workflow according to your threshold.")
                elif r.match_probability>=.60: st.warning("HUMAN REVIEW REQUIRED.")
                else: st.info("LOW CONFIDENCE — do not treat as a match.")

            st.subheader("📊 Privacy & Research Overview")
            x,y,z=st.columns(3)
            x.metric("Direct PII exposed", "0")
            y.metric("Processing mode", "Private / local")
            z.metric("Audit events", len(st.session_state["audit"]))
            st.info("Aggregate research outputs should be protected against small-cell disclosure before real-world release.")

else:
    if page=="Dashboard":
        st.header("📊 Command Dashboard")
        a,b,c,d=st.columns(4)
        a.metric("Privacy", "Protected")
        b.metric("ML Engine", "Online")
        c.metric("PII Exposure", "0")
        d.metric("Audit Events", len(st.session_state["audit"]))
        st.markdown("### Product flow")
        st.write("Upload → Scan → Sanitize → Generate privacy-preserving features → Match → Explain → Human review → Aggregate insights")
        st.markdown("### 🚀 Hackathon differentiators")
        for x in [
            "Live Privacy Shield with PII detection and automatic sanitization",
            "Explainable ML match probabilities with human-review thresholds",
            "Synthetic healthcare data generator for a safe, self-contained demo",
            "Privacy audit trail and privacy/utility awareness",
            "Architecture ready for future federated learning and differential privacy"
        ]: st.write("✓",x)
        st.info("Start with **Synthetic Data Lab** to generate a complete demo, then open **Private Matcher** and run the protected matching workflow.")
    else:
        st.header("📜 Privacy Audit Trail")
        if st.session_state["audit"]:
            st.dataframe(pd.DataFrame(st.session_state["audit"]), use_container_width=True)
        else:
            st.info("No audit events yet. Run a matching workflow first.")
        if st.button("Clear audit log"):
            st.session_state["audit"]=[]
            st.rerun()

